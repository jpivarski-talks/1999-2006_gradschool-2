/************************************************
*    CompHEP version 4.4.0      *
*------------------------------------------------
* Copyright (C) 2001-2003, CompHEP Collaboration*
************************************************/
/*
                d                 D     !                            
              ==>==\           /==<==\  !                            
                P1 |           |  P4 |  !                            
                   |           |     |  !                            
                D  |  Z     Z  |  d  |  !  d     d                   
              ==<==@-1---@-2---@==>==+==!==>==@==>==                 
                P2    P6 |  P7    P3 |  !  P3 |  P1                  
                         |           |  !    Z|-P8                   
                         |        H  |  !  H  3                      
                         \-----------+--!-----@                      
                                  P5 |  !  P5 |                      
                                     |  !    Z|-P9                   
                                     |  !  D  4  D                   
                                     \==!==<==@==<==                 
                                        !  P4    P2                  
*/
#include<math.h>
extern double *Q0, *Q1, *Q2;
extern double va[24];
#include"out_ext.h"
#include"out_int.h"
FNN F105;
double F105(void)
{
double TOTNUM,TOTDEN,RNUM,result;
static double C[3];double S[4];                                             
     
if(calcCoef[76])
{
S[0]=va[2]*va[2];
C[0]=+S[0]*(S[0]*(S[0]*(32*S[0]-96)+216)-216)+81;
S[1]=va[13]*va[13]*va[13]*va[13]*va[13]*va[13]*va[13]*va[13];
S[2]=va[2]*va[2]*va[2]*va[2]*va[2]*va[2];
C[1]=+486*S[1]*S[2];
S[3]=va[1]*va[1]*va[1]*va[1]*va[1]*va[1];
C[2]=+S[3];
}
S[0]=va[23]*va[23];
TOTNUM=+C[2]*S[0];
TOTDEN=+C[1];
RNUM=+C[0]*DP[3]*DP[2];
result=RNUM*(TOTNUM/TOTDEN)*Q1[1]*Q1[2]*Q1[3]*Q1[4];
 if(result>Fmax) Fmax=result; else if(result<-Fmax) Fmax=-result;
 if(color_weights)
 {
 }
 return result;
}
