/************************************************
*    CompHEP version 4.4.0      *
*------------------------------------------------
* Copyright (C) 2001-2003, CompHEP Collaboration*
************************************************/
/*
                      u     d     !  d     u                         
                    ==>==@==>=====!==>==@==>==                       
                      P1 |  P3    !  P3 |  P1                        
                       W+|P6      !   W+|-P8                         
                         1  H     !  H  3                            
                         @--------!-----@                            
                         |  P5    !  P5 |                            
                       W+|P7      !   W+|-P9                         
                      U  2  D     !  D  4  U                         
                    ==<==@==<=====!==<==@==<==                       
                      P2    P4    !  P4    P2                        
*/
#include<math.h>
extern double *Q0, *Q1, *Q2;
extern double va[24];
#include"out_ext.h"
#include"out_int.h"
FNN F16;
double F16(void)
{
double TOTNUM,TOTDEN,RNUM,result;
static double C[2];double S[3];                                             
     
if(calcCoef[9])
{
S[0]=va[2]*va[2]*va[2]*va[2]*va[2]*va[2];
C[0]=+S[0];
S[1]=va[17]*va[17]*va[17]*va[17];
S[2]=va[1]*va[1]*va[1]*va[1]*va[1]*va[1];
C[1]=+S[1]*S[2];
}
S[0]=va[23]*va[23];
TOTNUM=+C[1]*S[0];
TOTDEN=+C[0];
RNUM=+DP[3]*DP[2];
result=RNUM*(TOTNUM/TOTDEN)*Q2[3]*Q2[4]*Q0[1]*Q0[2];
 if(result>Fmax) Fmax=result; else if(result<-Fmax) Fmax=-result;
 if(color_weights)
 {
  color_weights[1] += result*(1)/(1);
 }
 return result;
}
