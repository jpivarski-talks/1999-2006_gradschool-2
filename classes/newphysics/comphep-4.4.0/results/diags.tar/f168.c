/************************************************
*    CompHEP version 4.4.0      *
*------------------------------------------------
* Copyright (C) 2001-2003, CompHEP Collaboration*
************************************************/
/*
                                  !  U     U                         
                      U     U    /!==<==@==<==                       
                    ==<==@==<==\ |!  P4 |  P1                        
                      P1 |  P3 | |!    Z|-P8                         
                        Z|P6   | |!  H  3                            
                         1  H  |/+!-----@                            
                         @-----+/|!  P5 |                            
                         |  P5 | |!    Z|-P9                         
                        Z|P7   | |!  U  4  U                         
                      U  2  U  \=+!==<==@==<==                       
                    ==<==@==<====/!  P3    P2                        
                      P2    P4    !                                  
*/
#include<math.h>
extern double *Q0, *Q1, *Q2;
extern double va[24];
#include"out_ext.h"
#include"out_int.h"
FNN F168;
double F168(void)
{
double TOTNUM,TOTDEN,RNUM,result;
static double C[3];double S[4];                                             
     
if(calcCoef[121])
{
S[0]=va[2]*va[2];
C[0]=+S[0]*(S[0]*(S[0]*(512*S[0]-768)+864)-432)+81;
S[1]=va[13]*va[13]*va[13]*va[13]*va[13]*va[13]*va[13]*va[13];
S[2]=va[2]*va[2]*va[2]*va[2]*va[2]*va[2];
C[1]=+972*S[1]*S[2];
S[3]=va[1]*va[1]*va[1]*va[1]*va[1]*va[1];
C[2]=+S[3];
}
S[0]=va[23]*va[23];
TOTNUM=+C[2]*S[0];
TOTDEN=+C[1];
RNUM=+C[0]*DP[5]*DP[0];
result=RNUM*(TOTNUM/TOTDEN)*Q1[1]*Q1[2]*Q1[3]*Q1[4];
 if(result>Fmax) Fmax=result; else if(result<-Fmax) Fmax=-result;
 if(color_weights)
 {
 }
 return result;
}
