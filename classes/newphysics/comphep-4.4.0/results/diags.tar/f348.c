/************************************************
*    CompHEP version 4.4.0      *
*------------------------------------------------
* Copyright (C) 2001-2003, CompHEP Collaboration*
************************************************/
/*
                      c     d     !  d     c                         
                    ==>==@==>=====!==>==@==>==                       
                      P1 |  P3    !  P3 |  P1                        
                       W+|P6      !   W+|-P8                         
                         1  H     !  H  3                            
                         @--------!-----@                            
                         |  P5    !  P5 |                            
                       W+|P7      !   W+|-P9                         
                      U  2  D     !  D  4  U                         
                    ==<==@==<=====!==<==@==<==                       
                      P2    P4    !  P4    P2                        
*/
#include<math.h>
extern double *Q0, *Q1, *Q2;
extern double va[24];
#include"out_ext.h"
#include"out_int.h"
FNN F348;
double F348(void)
{
double TOTNUM,TOTDEN,RNUM,result;
static double C[5];double S[6];                                             
     
if(calcCoef[259])
{
S[0]=va[9]*va[9]*va[9]*va[9];
C[0]=+S[0];
S[1]=va[9]*va[9];
C[1]=+4*S[1];
C[2]=+2*S[1];
S[2]=va[2]*va[2]*va[2]*va[2]*va[2]*va[2];
C[3]=+4*S[2];
S[3]=va[20]*va[20];
S[4]=va[17]*va[17];
S[5]=va[1]*va[1]*va[1]*va[1]*va[1]*va[1];
C[4]=+S[3]*S[4]*S[5];
}
TOTNUM=+C[4];
S[0]=va[23]*va[23];
TOTDEN=+C[3]*S[0];
RNUM=+C[2]*(DP[1]*(DP[0]*(DP[3]-DP[5])+DP[2]*(DP[5]-DP[3])+DP[4]*(S[0]+
 DP[1]))+S[0]*(-DP[3]*DP[2]-DP[5]*DP[0]))+S[0]*(DP[2]*(4*DP[3]*S[0]+C[1]*
 DP[5]))-C[0]*DP[4]*DP[1];
result=RNUM*(TOTNUM/TOTDEN)*Q2[1]*Q2[2];
 if(result>Fmax) Fmax=result; else if(result<-Fmax) Fmax=-result;
 if(color_weights)
 {
  color_weights[1] += result*(1)/(1);
 }
 return result;
}
