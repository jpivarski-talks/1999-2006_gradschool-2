/************************************************
*    CompHEP version 4.4.0      *
*------------------------------------------------
* Copyright (C) 2001-2003, CompHEP Collaboration*
************************************************/
/*
                      c     d     !  d     c                         
                    ==>==@==>=====!==>==@==>==                       
                      P1 |  P3    !  P3 |  P1                        
                       W+|P6      !   W+|-P8                         
                         1  H     !  H  3                            
                         @--------!-----@                            
                         |  P5    !  P5 |                            
                       W+|P7      !   W+|-P9                         
                      b  2  c     !  c  4  b                         
                    ==>==@==>=====!==>==@==>==                       
                      P2    P4    !  P4    P2                        
*/
#include<math.h>
extern double *Q0, *Q1, *Q2;
extern double va[24];
#include"out_ext.h"
#include"out_int.h"
FNN F405;
double F405(void)
{
double TOTNUM,TOTDEN,RNUM,result;
static double C[21];double S[8];                                            
     
if(calcCoef[301])
{
S[0]=va[11]*va[11];
S[1]=va[9]*va[9];
C[0]=+S[1]*(S[0]*(2*(S[0]+S[1])));
S[2]=va[9]*va[9]*va[9]*va[9];
C[1]=+4*S[2];
C[2]=+2*S[2];
S[3]=va[11]*va[11]*va[11]*va[11];
C[3]=+S[1]*(6*S[0]+2*S[1])+S[3];
C[4]=+S[1]*(6*S[0]+2*S[1]);
C[5]=+2*S[0]+4*S[1];
C[6]=+8*S[0]*S[2];
C[7]=+4*S[1];
C[8]=+2*S[1];
C[9]=+8*S[0]*S[1];
C[10]=+4*S[0];
C[11]=+S[1]*(4*(S[0]+S[1]));
C[12]=+2*(S[0]+S[1]);
C[13]=+4*S[0]*S[2];
C[14]=+4*S[0]*S[1];
C[15]=+2*S[0]*S[2];
C[16]=+2*S[0]*S[1];
C[17]=+S[1]*(2*(S[0]+S[1]));
C[18]=+S[1]*(S[0]+S[1]);
S[4]=va[2]*va[2]*va[2]*va[2]*va[2]*va[2];
C[19]=+4*S[4];
S[5]=va[22]*va[22];
S[6]=va[20]*va[20];
S[7]=va[1]*va[1]*va[1]*va[1]*va[1]*va[1];
C[20]=+S[5]*S[6]*S[7];
}
TOTNUM=+C[20];
S[0]=va[23]*va[23]*va[23]*va[23]*va[23]*va[23];
TOTDEN=+C[19]*S[0];
S[1]=va[23]*va[23];
S[2]=DP[3]*DP[3];
S[3]=DP[0]*DP[0];
S[4]=DP[2]*DP[2];
S[5]=DP[5]*DP[5];
RNUM=+S[1]*(S[1]*(DP[5]*(DP[0]*(S[1]*(4*S[1]-C[5])+C[4]-C[8]*DP[1]-C[12]*
 DP[4])+DP[2]*(C[7]*S[1]-C[11]+C[8]*DP[1])+DP[3]*(C[10]*S[1]-C[9]+C[12]*
 DP[4])+C[14]*DP[5])+DP[1]*(DP[4]*(C[5]*S[1]-C[3]+C[8]*DP[1]+C[12]*DP[4])+
 DP[3]*(C[8]*(DP[0]-DP[2]))+C[0]-C[14]*S[1])+DP[2]*(DP[0]*(C[7]*S[1]-C[11]+
 C[12]*DP[4])+DP[3]*(C[4]-C[5]*S[1]-C[12]*DP[4])+C[1]*DP[2]))+DP[2]*(C[17]*(
 DP[4]*(DP[2]-DP[0]+DP[3])+DP[1]*(DP[3]-DP[5]))+C[13]*(DP[0]-DP[2]-DP[3])+
 DP[1]*(C[2]*DP[2]-C[1]*DP[0])+DP[5]*(C[6]-C[11]*DP[4]))+DP[5]*(C[17]*(
 DP[4]*(DP[0]-DP[3]+DP[5])+DP[1]*DP[0])+C[13]*(DP[3]-DP[0]-DP[5])+DP[1]*(
 C[16]*DP[5]-C[14]*DP[3]))+DP[1]*(DP[0]*(C[2]*DP[0]-C[17]*DP[3])+C[16]*
 S[2]))+DP[1]*(DP[4]*(C[17]*(DP[0]*(DP[5]-DP[2]-DP[3])+DP[2]*(DP[3]-DP[5])-
 DP[5]*DP[3])+C[18]*(S[3]+S[4]+S[2]+S[5]))+C[13]*(DP[0]*(DP[2]+DP[3]-DP[5])+
 DP[2]*(DP[5]-DP[3])+DP[5]*DP[3])+C[15]*(-S[3]-S[4]-S[2]-S[5]));
result=RNUM*(TOTNUM/TOTDEN)*Q2[1]*Q2[2];
 if(result>Fmax) Fmax=result; else if(result<-Fmax) Fmax=-result;
 if(color_weights)
 {
  color_weights[0] += result*(1)/(1);
 }
 return result;
}
