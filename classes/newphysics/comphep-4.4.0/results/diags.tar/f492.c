/************************************************
*    CompHEP version 4.4.0      *
*------------------------------------------------
* Copyright (C) 2001-2003, CompHEP Collaboration*
************************************************/
/*
                      C     C     !  C     C                         
                    ==<==@==<=====!==<==@==<==                       
                      P1 |  P4    !  P4 |  P1                        
                        Z|P6      !    Z|-P8                         
                         1  H     !  H  3                            
                         @--------!-----@                            
                         |  P5    !  P5 |                            
                        Z|P7      !    Z|-P9                         
                      d  2  d     !  d  4  d                         
                    ==>==@==>=====!==>==@==>==                       
                      P2    P3    !  P3    P2                        
*/
#include<math.h>
extern double *Q0, *Q1, *Q2;
extern double va[24];
#include"out_ext.h"
#include"out_int.h"
FNN F492;
double F492(void)
{
double TOTNUM,TOTDEN,RNUM,result;
static double C[8];double S[8];                                             
     
if(calcCoef[367])
{
S[0]=va[2]*va[2];
S[1]=va[9]*va[9];
S[2]=va[6]*va[6];
S[3]=va[9]*va[9]*va[9]*va[9];
C[0]=+S[1]*(S[0]*(S[2]*(S[0]*(S[2]*(S[0]*(288-128*S[0])-288)-72*S[1])+108*(
 S[1]+S[2]))+S[3]*(72*S[0]-108))+S[1]*(81*(S[1]-S[2])));
C[1]=+S[1]*(S[0]*(S[0]*(144*S[1]-72*S[2])+108*S[2]-216*S[1])+162*S[1]-81*
 S[2]);
C[2]=+S[0]*(S[2]*(S[0]*(S[2]*(S[0]*(128*S[0]-288)+468)-72*S[1])+108*S[1]-
 324*S[2])+S[3]*(72*S[0]-108))+81*(S[2]*(S[2]-S[1])+S[3]);
C[3]=+S[0]*(S[0]*(S[2]*(S[2]*(S[0]*(128*S[0]-288)+180)-72*S[1])+72*S[3])+
 S[1]*(108*(S[2]-S[1])))+S[1]*(81*(S[1]-S[2]));
C[4]=+S[1]*(S[0]*(S[0]*(72*(S[1]-S[2]))+108*(S[2]-S[1]))+81*(S[1]-S[2]));
C[5]=+S[1]*(S[0]*(72*S[0]-108)+81);
S[4]=va[13]*va[13]*va[13]*va[13]*va[13]*va[13]*va[13]*va[13];
S[5]=va[6]*va[6]*va[6]*va[6];
S[6]=va[2]*va[2]*va[2]*va[2]*va[2]*va[2];
C[6]=+324*S[4]*S[5]*S[6];
S[7]=va[1]*va[1]*va[1]*va[1]*va[1]*va[1];
C[7]=+S[7];
}
S[0]=va[23]*va[23];
TOTNUM=+C[7]*S[0];
TOTDEN=+C[6];
RNUM=+DP[3]*(C[5]*(DP[0]*(DP[1]-DP[5])+DP[4]*(DP[5]-DP[1])+DP[3]*DP[2])-
 C[1]*DP[2])+DP[0]*(C[3]*DP[5]-C[4]*DP[1])+DP[4]*(C[2]*DP[1]-C[4]*DP[5])+
 C[0]*DP[2];
result=RNUM*(TOTNUM/TOTDEN)*Q2[3]*Q2[4]*Q0[1]*Q0[2];
 if(result>Fmax) Fmax=result; else if(result<-Fmax) Fmax=-result;
 if(color_weights)
 {
  color_weights[1] += result*(1)/(1);
 }
 return result;
}
