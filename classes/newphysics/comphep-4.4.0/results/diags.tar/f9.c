/************************************************
*    CompHEP version 4.4.0      *
*------------------------------------------------
* Copyright (C) 2001-2003, CompHEP Collaboration*
************************************************/
/*
                      u     s     !  s     u                         
                    ==>==@==>=====!==>==@==>==                       
                      P1 |  P4    !  P4 |  P1                        
                       W+|P6      !   W+|-P8                         
                         1  H     !  H  3                            
                         @--------!-----@                            
                         |  P5    !  P5 |                            
                       W+|P7      !   W+|-P9                         
                      d  2  c     !  c  4  d                         
                    ==>==@==>=====!==>==@==>==                       
                      P2    P3    !  P3    P2                        
*/
#include<math.h>
extern double *Q0, *Q1, *Q2;
extern double va[24];
#include"out_ext.h"
#include"out_int.h"
FNN F9;
double F9(void)
{
double TOTNUM,TOTDEN,RNUM,result;
static double C[11];double S[8];                                            
     
if(calcCoef[6])
{
S[0]=va[10]*va[10];
C[0]=+4*S[0];
S[1]=va[10]*va[10]*va[10]*va[10];
S[2]=va[9]*va[9]*va[9]*va[9];
C[1]=+S[1]+S[2];
S[3]=va[9]*va[9];
C[2]=+4*S[3];
C[3]=+4*S[0]*S[3];
C[4]=+2*(S[0]+S[3]);
C[5]=+2*S[3];
C[6]=+2*S[0];
C[7]=+2*S[0]*S[3];
C[8]=+S[0]*S[3];
S[4]=va[2]*va[2]*va[2]*va[2]*va[2]*va[2];
C[9]=+4*S[4];
S[5]=va[20]*va[20];
S[6]=va[18]*va[18];
S[7]=va[1]*va[1]*va[1]*va[1]*va[1]*va[1];
C[10]=+S[5]*S[6]*S[7];
}
TOTNUM=+C[10];
S[0]=va[23]*va[23]*va[23]*va[23]*va[23]*va[23];
TOTDEN=+C[9]*S[0];
S[1]=va[23]*va[23];
S[2]=DP[0]*DP[0];
S[3]=DP[1]*DP[1];
S[4]=DP[4]*DP[4];
S[5]=DP[5]*DP[5];
RNUM=+S[1]*(S[1]*(DP[0]*(DP[5]*(S[1]*(4*S[1]-C[4])+C[7]-C[5]*DP[2]-C[6]*
 DP[3])+DP[1]*(C[0]*S[1]-C[3]+C[6]*DP[3])+DP[4]*(C[2]*S[1]-C[3]+C[5]*DP[2])+
 C[3]*DP[0])+DP[2]*(DP[3]*(C[4]*S[1]-C[1]+C[5]*DP[2]+C[6]*DP[3])+DP[1]*(
 C[5]*(DP[5]-DP[4])))+DP[4]*(DP[1]*(C[7]-C[4]*S[1]-C[6]*DP[3])+C[6]*DP[5]*
 DP[3]))+C[7]*(DP[0]*(DP[2]*(DP[0]-DP[4]+DP[5])+DP[3]*(DP[0]-DP[1]+DP[5]))+
 DP[1]*(DP[2]*(DP[1]+DP[4]-DP[5])+DP[4]*DP[3])+DP[3]*(DP[4]*(DP[4]-DP[5])))+
 DP[0]*(C[3]*(-DP[2]*DP[1]-DP[4]*DP[3])))+DP[2]*(DP[3]*(C[7]*(DP[0]*(DP[5]-
 DP[1]-DP[4])+DP[1]*(DP[4]-DP[5])-DP[5]*DP[4])+C[8]*(S[2]+S[3]+S[4]+S[5])));
result=RNUM*(TOTNUM/TOTDEN)*Q2[1]*Q2[2];
 if(result>Fmax) Fmax=result; else if(result<-Fmax) Fmax=-result;
 if(color_weights)
 {
  color_weights[1] += result*(1)/(1);
 }
 return result;
}
